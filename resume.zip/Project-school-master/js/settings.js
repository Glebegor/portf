var setting = document.getElementById('settings');

function settings(){
    setting.classList.toggle("settingsactive")
    
    // if(setting.style.right = "-300px"){
    //     setting.style.right = "0px"

    // }else if(setting.style.right = "0px"){
    //     setting.style.right = "-300px"

    // }

    console.log('asdas')
};